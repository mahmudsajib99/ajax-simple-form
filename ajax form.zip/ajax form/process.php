<?php

$name =!empty($_POST['naam'])?$_POST['name'] : 'empty';
$address =!empty($_POST['address'])?$_POST['address'] : 'empty';




echo "Name: ".$name;
echo "<br>";
echo "Address: ".$address;

?>