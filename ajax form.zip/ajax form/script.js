 jQuery(document).ready(function(){
 	jQuery(".form1").on('submit', function(){
 		

 		var naam =jQuery('input#naam').val();
 		var address =jQuery('input#address').val();


 		$.ajax({

 			'url'	:'process.php',
 			'data'	:{
 				'naam'	:naam,
 				'address' :address

 			},
 			'type'	: 'POST',
 			'success'	: function(output){
 				jQuery(".sajib").html(output);
 			}
 		});

 		return false;
 	});


 });